//
//  IEEE754.cpp
//  Exercise
//
//  Created by Yefa Mai on 10/15/16.
//  Copyright © 2016 yefa mai. All rights reserved.
//

#include "IEEE754.hpp"

IEEE754::IEEE754(int n){
    if (n==3){
        string _sign;
        double _decimal;
    int exp;
    
    initial();
    _sign =sign();
    exp = expon();
    _decimal = decimal();
    cout <<"Your IEE750 convert float point number is :";
    cout <<_sign<<1+_decimal<<"*2^"<<exp<<endl;
    }
}

void IEEE754::getvalue(char number[32]){
    for (int i = 0 ;i <32;i++)
        _number[i]=number[i];
}

void IEEE754::HexiInitial(string number){
    string _sign;
    double _decimal;
    int exp;
    
    for (int i = 0 ;i <32;i++)
        _number[i]=number[i];
    
     _sign =sign();
     exp = expon();
     _decimal = decimal();
    
     cout <<"Your IEE750 convert float point number is :";
     cout <<_sign<<1+_decimal<<"*2^"<<exp<<endl;
};

void IEEE754::initial(){
    double check;
    char number[32];
    cout<<"Please enter 32-bits Binary code: ";
    cin >> number;
    check = strlen(number);
    if (check < 32)                        // To fill the zero the rest of the bits
    {
        for (int i = check; i < 32; i++)
            number[i] = '0';
    }
    getvalue(number);

    
}

string IEEE754::sign(){
    string sign;
    if ((int)_number[0] == 48){
        sign = "+";
    }else {
        sign = "-";
    }
    return sign;
}

int IEEE754::expon(){
    int exp,sum;
    
    sum = ((int)_number[1]-48)*pow(2,7)+((int)_number[2]-48)*pow(2,6)+((int)_number[3]-48)*pow(2,5)+((int)_number[4]-48)*pow(2,4)+((int)_number[5]-48)*pow(2,3)+((int)_number[6]-48)*pow(2,2)+((int)_number[7]-48)*pow(2,1)+((int)_number[8]-48)*pow(2,0);
    exp = sum - 127;
    
    return exp;
}
double IEEE754::decimal(){
    double sum = 0;
    for (int i = 9,j =1 ; i < 32;i++,j++)
       sum =sum+((int)_number[i]-48)*pow(0.5,j);
    
    return sum;
}