//
//  InstruAssembly.cpp
//  Exercise
//
//  Created by Yefa Mai on 10/12/16.
//  Copyright © 2016 yefa mai. All rights reserved.
//

#include "InstruAssembly.hpp"

Instru::Instru(int n){
    if (n == 2)
       Initial();
    
};

void Instru::Initial(){
    char Instu[32];   // Create the 32 bits instruction set
    double check;        // To check the user enter whether is 32 bits ,otherwise 0 append.
        cout <<"Please enter your 32 bits Instruction (Binary) :";
    cin >> Instu;
    check = strlen(Instu);
    if (check < 32)                         // To fill the zero the rest of the bits
    { for (int i = check; i < 32; i++)
        Instu[i] = '0';
    }
    cout <<"You Binary code is :";
    for (int i = 0; i < 32; i = i+4)
       cout <<Instu[i]<<Instu[i+1]<<Instu[i+2]<<Instu[i+3]<<" ";
    cout<<endl;
    getValue(Instu);
    if (Instu[0] == '0' && Instu[1] == '0' && Instu[2] == '0' && Instu[3] == '0' && Instu[4] == '0' && Instu[5] == '0' ){
        if (Instu[26] == '0' && Instu[27] == '0' && Instu[28] == '1' && Instu[29] == '0' && Instu[30] == '0' && Instu[31] == '0'){
            J_type();
        }else {
            R_type();
            }
    }else {
        
        int type;
        type = ((int)Instu[0]-48)*32+((int)Instu[1]-48)*16+((int)Instu[2]-48)*8+((int)Instu[3]-48)*4+((int)Instu[4]-48)*2+((int)Instu[5]-48)*1;
        if (type == 2|| type == 3||type == 0){
            J_type();}
        else {
           I_type(); }
    }
    
}
void Instru::getValue(char Instru[32]){
    for (int i = 0; i <= 31; i++)
        _Instru[i] = Instru[i];

}


void Instru::R_type(){
    string reg_rs,reg_rt,reg_rd,funcName;
    
    reg_rs = rs();
    reg_rt = rt();
    reg_rd = rd();
    funcName = R_function();
    cout <<"R_type : "<<funcName<<" "<<reg_rd <<" "<<reg_rs<<" "<<reg_rt<<endl;
    
    
}

void Instru::I_type(){
    int I_immNum;
    string reg_rs,reg_rt,op_na;
    reg_rs = rs();
    reg_rt = rt();
    op_na = I_op(reg_rt);
    I_immNum = I_immediate();
    cout <<"I_type : "<<op_na<<" "<<reg_rt<<" "<<I_immNum<<"("<<reg_rs<<")"<<endl;
    
    
};

void Instru::J_type(){
    int J_immNum;
    string op_na,reg_rs;
    op_na = J_op();
    reg_rs = rs();
    J_immNum = J_immediate();
    if ( 0 ==((int)_Instru[11]-48)*16+((int)_Instru[12]-48)*8+((int)_Instru[13]-48)*4+((int)_Instru[14]-48)*2+((int)_Instru[15]-48)*1)
    {
        cout <<"J_type : "<<"jr" <<" "<<reg_rs<<" 0 0000 0000 0000 1000 "<<endl;
    }else {
        cout <<"J_type : "<<op_na<<" "<<J_immNum<<endl;}
};

string Instru::rs(){
    int regs;
    string reg_rs;
    regs = ((int)_Instru[6]-48)*16+((int)_Instru[7]-48)*8+((int)_Instru[8]-48)*4+((int)_Instru[9]-48)*2+((int)_Instru[10]-48)*1;
    reg_rs = reg_name(regs);
    return reg_rs;
};

string Instru::rt(){
    int regs;
    string reg_rt;
    regs = ((int)_Instru[11]-48)*16+((int)_Instru[12]-48)*8+((int)_Instru[13]-48)*4+((int)_Instru[14]-48)*2+((int)_Instru[15]-48)*1;
    reg_rt = reg_name(regs);
    return reg_rt;
    
};

string Instru::rd(){
    int regs;
    string reg_rd;
    regs = ((int)_Instru[16]-48)*16+((int)_Instru[17]-48)*8+((int)_Instru[18]-48)*4+((int)_Instru[19]-48)*2+((int)_Instru[20]-48)*1;
    reg_rd= reg_name(regs);
    return reg_rd;
    
};

string Instru::reg_name(int regs){
    string regName;
    switch (regs){
        case 0:
            regName =  "$Zero";
            break;
        case 2:
            regName =  "$V0";
            break;
        case 3:
            regName =  "$V1";
            break;
        case 4:
            regName =  "$A0";
            break;
        case 5:
            regName =  "$A1";
            break;
        case 6:
            regName =  "$A2";
            break;
        case 7:
            regName =  "$A3";
            break;
        case 8:
            regName =  "$t0";
            break;
        case 9:
            regName =  "$t1";
            break;
        case 10:
            regName =  "$t2";
            break;
        case 11:
            regName =  "$t3";
            break;
        case 12:
            regName =  "$t4";
            break;
        case 13:
            regName =  "$t5";
            break;
        case 14:
            regName =  "$t6";
            break;
        case 15:
            regName =  "$t7";
            break;
        case 16:
            regName =  "$S0";
            break;
        case 17:
            regName =  "$S1";
            break;
        case 18:
            regName =  "$S2";
            break;
        case 19:
            regName =  "$S3";
            break;
        case 20:
            regName =  "$S4";
            break;
        case 21:
            regName =  "$S5";
            break;
        case 22:
            regName =  "$S6";
            break;
        case 23:
            regName =  "$S7";
            break;
        case 24:
            regName =  "$t7";
            break;
        case 25:
            regName =  "$t8";
            break;
        case 28:
            regName =  "$SP";
            break;
        case 29:
            regName =  "$SP";
            break;
        case 30:
            regName =  "$fP";
            break;
        case 31:
            regName =  "$ra";
            break;
        default:
            regName = "No define register";
            break;
    };
    return regName;
    
}

string Instru::R_function(){
    int func;
    string FuncName;
    func = ((int)_Instru[26]-48)*32+((int)_Instru[27]-48)*16+((int)_Instru[28]-48)*8+((int)_Instru[29]-48)*4+((int)_Instru[30]-48)*2+((int)_Instru[31]-48)*1;
    cout << func<<endl;
    
    switch (func){
        case 0:
            FuncName = "sll";
            break;
        case 32:
            FuncName = "add";
            break;
        case 33:
            FuncName = "addu";
            break;
        case 34:
            FuncName = "sub";
            break;
        case 36:
            FuncName = "and";
            break;
        case 26:
            FuncName = "div";
            break;
        case 27:
            FuncName = "divu";
            break;
        case 24:
            FuncName = "mul";
            break;
        case 25:
            FuncName = "multu";
            break;
        case 37:
            FuncName = "or";
            break;
        case 4:
            FuncName = "sllv";
            break;
        case 42:
            FuncName = "slt";
            break;
        case 43:
            FuncName = "sltu";
            break;
        case 3:
            FuncName = "sra";
            break;
        case 2:
            FuncName = "srl";
            break;
        case 6:
            FuncName = "srlv";
            break;
        case 35:
            FuncName = "subu";
            break;
        case 12:
            FuncName = "SYSCALL";
            break;
        case 38:
            FuncName = "xor";
            break;
        default :
            FuncName = "Undefined";
            break;
    }
    return FuncName;
    
};

string Instru::I_op(string &reg_rt){
    int op;
    int rt;
    string opName ="Undefined";
    op = ((int)_Instru[0]-48)*32+((int)_Instru[1]-48)*16+((int)_Instru[2]-48)*8+((int)_Instru[3]-48)*4+((int)_Instru[4]-48)*2+((int)_Instru[5]-48)*1;
    switch (op){
        case 16:
            opName = "addi";
            break;
        case 17:
            opName = "addiu";
            break;
        case 12:
            opName = "andi";
            break;
        case 8:
            opName = "beq";
            break;
        case 1:
            rt = ((int)_Instru[11]-48)*16+((int)_Instru[12]-48)*8+((int)_Instru[13]-48)*4+((int)_Instru[14]-48)*2+((int)_Instru[15]-48)*1;
            if (rt == 1){
                opName = "bgez";
                reg_rt = "00001";
            } else if(rt == 17){
                opName = "bgezal";
                reg_rt = "10001";
            } else if (rt == 0){
                opName = "bltz";
                reg_rt = "00000";
            } else if (rt == 16){
                opName = "bltzal";
                reg_rt = "10000";
            }
            break;
        case 5:
            opName = "bne";
            break;
        case 6:
            opName = "blez";
            reg_rt = "00000";
        case 7:
            opName = "blez";
            reg_rt = "00000";
            break;
        case 32:
            opName = "load";
            break;
        case 15:
            opName = "lui";
            break;
        case 35:
            opName = "lw";
            break;
        case 13:
            opName = "ori";
            break;
        case 40:
            opName = "sb";
            break;
        case 10:
            opName = "slti";
            break;
        case 11:
            opName = "sltiu";
            break;
        case 43:
            opName = "sw";
            break;
        case 14:
            opName = "xori";
            break;
        default :
            opName = "Undefined";
            break;
    }
    return opName;
}

string Instru::J_op(){
    int op;
    string opName ="Undefined";
    op = ((int)_Instru[0]-48)*32+((int)_Instru[1]-48)*16+((int)_Instru[2]-48)*8+((int)_Instru[3]-48)*4+((int)_Instru[4]-48)*2+((int)_Instru[5]-48)*1;
    switch (op){
        case 2:
            opName ="J";
            break;
        case 3:
            opName = "jal";
            break;
        default :
            opName = "Undefined";
            break;
    }
    return opName;
}
int Instru::I_immediate(){
    int sum = 0;
    for (int i = 31,j = 0; i >=16 ; i--,j++)
    {
        sum = sum + (((int)_Instru[i]-48)*pow(2,j));
    }
    
    return sum;
};

int Instru::J_immediate(){
    int sum = 0;
    for (int i = 31,j = 0; i >=6 ; i--,j++)
    {
        sum = sum + (((int)_Instru[i]-48)*pow(2,j));
    }
    return sum;
};


void Instru::HexiInitial(string Hexi){
    
    char Instu[32];
    for (int i = 0; i <= 31; i++)
        Instu[i] = Hexi[i];
    getValue (Instu);
        if (Instu[0] == '0' && Instu[1] == '0' && Instu[2] == '0' && Instu[3] == '0' && Instu[4] == '0' && Instu[5] == '0' ){
            if (Instu[26] == '0' && Instu[27] == '0' && Instu[28] == '1' && Instu[29] == '0' && Instu[30] == '0' && Instu[31] == '0'){
                J_type();
            }else {
                R_type();
            }
        }else {
            
            int type;
            type = ((int)Instu[0]-48)*32+((int)Instu[1]-48)*16+((int)Instu[2]-48)*8+((int)Instu[3]-48)*4+((int)Instu[4]-48)*2+((int)Instu[5]-48)*1;
            if (type == 2|| type == 3||type == 0){
                J_type();}
            else {
                I_type(); }
        }

};