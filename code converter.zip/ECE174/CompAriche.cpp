//
//  CompAriche.cpp
//  Exercise
//
//  Created by Yefa Mai on 10/15/16.
//  Copyright © 2016 yefa mai. All rights reserved.
//

#include "CompAriche.hpp"



void FuncEnd();
int choice();

int main(){
    system ("title Hexi convert to Binary 32-bits --- Created by Yefa Mai ");
    int pick = choice();
    Hexi A(pick);
    Instru B(pick);
    IEEE754 C(pick);
    FloatToBinary D(pick);
    
    
    FuncEnd();
    
    return 0;
}

int choice(){
    cout <<"Do you want to convert the Hexi to Binary, select 1 "<<endl;
    cout <<"Do you want to convert Binary to Assembly language,select 2"<<endl;
    cout <<"DO you want to convert Binary code using the IEEE754 format,select 3"<<endl;
    cout <<"Do you want to convertt the floating point number by using IEEE754 format,select 4"<<endl;
    
    int _choice;
    
    
    cin >>_choice;
    
    return _choice;
}



void FuncEnd(){
    char leave;
    cout << "\n\nDo you want to run this program again ? Yes(Y) Or No(N) ";
    cin >> leave;
    if (leave == 'Y' || leave == 'y'){
        main();}
    else {
        cout <<"Thank you to use."<<endl;
        system("pause");
    }
};