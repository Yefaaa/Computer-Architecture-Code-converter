//
//  HexiConvBinary.hpp
//  Exercise
//
//  Created by Yefa Mai on 10/11/16.
//  Copyright © 2016 yefa mai. All rights reserved.
//

#ifndef HexiConvBinary_hpp
#define HexiConvBinary_hpp

#include <stdio.h>
#include <iostream>
#include <cstring>
#include <stdlib.h>
#include "InstruAssembly.hpp"
#include "IEEE754.hpp"


using namespace std;

class Hexi : public Instru, public IEEE754{
private:
    char _Hexi[9];   // Create 8_bits Hexi
          
    string _Binary;
    Hexi(){};
public:
    Hexi(int n);
    void getHeix(char []);
    void Initial();
    void conver();
    void connect(string);
    ~Hexi(){};
        
    
};


#endif /* HexiConvBinary_hpp */
