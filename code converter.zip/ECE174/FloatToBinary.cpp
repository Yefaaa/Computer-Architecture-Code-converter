//
//  FloatToBinary.cpp
//  Fun
//
//  Created by Yefa Mai on 10/17/16.
//  Copyright © 2016 yefa mai. All rights reserved.
//

#include "FloatToBinary.hpp"




FloatToBinary::FloatToBinary(int n){
    if (n==4){
        intial();
    }
}

void FloatToBinary::intial(){
    float number;
    cout <<"Enter the floating point number: ";
    cin>>number;
    getvalue(number);
    excute();
    
    
    
}
void FloatToBinary::excute(){
    union
    {
        float input;   // assumes sizeof(float) == sizeof(int)
        int   output;
    }    data;
    
    data.input = _number;
    bitset<sizeof(float) * CHAR_BIT>   bits(data.output);
// Format output
    cout << "Your binary code is :"<<bits[31]<<" ";
     for (int i=30;i>=23;i--)
         cout <<bits[i];
    cout <<" ";
    for (int i=22;i>=0;i--)
        cout <<bits[i];
    cout<< endl;
   
    
 // convert the int to string
    string code;
    for (int i=31;i>=0;i--){
        code = code +to_string(bits[i]);
    }

    char check;
    cout <<"\nDo you want to conver it back to floating point number to check it ? Yes(Y) or No(N)";
    cin>>check;
    cout <<endl;
    
    if (check =='Y'||check =='y')
        IEEE754::HexiInitial(code);
    
};




