//
//  InstruAssembly.hpp
//  Exercise
//
//  Created by Yefa Mai on 10/12/16.
//  Copyright © 2016 yefa mai. All rights reserved.
//

#ifndef InstruAssembly_hpp
#define InstruAssembly_hpp

#include <stdio.h>
#include <iostream>
#include <cstring>
#include <stdlib.h>
#include <math.h>
#include <string.h>

using namespace std;



class Instru{
private:
    char _Instru[32];
    Instru(){};
    friend class Hexi;
public:
    Instru(int n);
    void getValue(char *Instru);
    void HexiInitial(string);
    void Initial();
    void R_type();
    void I_type();
    void J_type();
    string rs();
    string rt();
    string rd();
    string reg_name(int regs);
    string R_function();
    string I_op(string &reg_rt);
    string J_op();
    int I_immediate();
    int J_immediate();
    ~Instru(){};
    
    
};


#endif /* InstruAssembly_hpp */
