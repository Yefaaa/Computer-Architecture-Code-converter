//
//  HexiConvBinary.cpp
//  Exercise
//
//  Created by Yefa Mai on 10/11/16.
//  Copyright © 2016 yefa mai. All rights reserved.
//

#include "HexiConvBinary.hpp"



Hexi :: Hexi(int n){
    if (n == 1){
        Initial();
    }
}

void Hexi::Initial(){
    double check; // To check the user enter whether is 8 bits ,otherwise 0 append.
    char Hexi[9];
    cout <<"Please enter your 8 bits Hexi (Capital Letter) : ";
    cin >> Hexi;
    check = strlen(Hexi);
    if (check < 8)                        // To fill the zero the rest of the bits
    {
        for (int i = check; i < 8; i++)
          Hexi[i] = '0';
    }
    
    getHeix(Hexi);
    conver();
};

void Hexi::getHeix(char Hexi[8]){
    for(int i= 0; i < 8;i++)
        _Hexi[i] = Hexi[i];
 
};

void Hexi::conver(){
    string num[8];
    string Bin,BinUsed;
    for (int i= 0; i < 8;i++){
        switch ((int)_Hexi[i]){
            case 48:
                num[i]="0000";
                break;
            case 49:
                num[i]="0001";
                break;
            case 50:
                num[i]="0010";
                break;
            case 51:
                num[i]="0011";
                break;
            case 52:
                num[i]="0100";
                break;
            case 53:
                num[i]="0101";
                break;
            case 54:
                num[i]="0110";
                break;
            case 55:
                num[i]="0111";
                break;
            case 56:
                num[i]="1000";
                break;
            case 57:
                num[i]="1001";
                break;
            case 65:
                num[i]="1010";
                break;
            case 66:
                num[i]="1011";
                break;
            case 67:
                num[i]="1100";
                break;
            case 68:
                num[i]="1101";
                break;
            case 69:
                num[i]="1110";
                break;
            case 70:
                num[i]="1111";
                break;
                
        }
    };
    for (int i= 0; i < 8;i++)
    {
        Bin = Bin+num[i]+" ";
        BinUsed = BinUsed+num[i];
    }
    cout <<"You Binary code is : ";
    cout << Bin <<endl;
    
    connect(BinUsed);
}


void Hexi::connect(string BinUsed){
    char choice;
    cout <<"\nDo you want to conver it to Assembly language ? Yes(Y) or No(N) ";
    cin >> choice;
    if (choice == 'Y'||choice == 'y')
          Instru::HexiInitial(BinUsed);
    cout <<"\nDo you want to convert it to floating point ? Yes(Y) or No(N) ";
    cin>>choice;
    if (choice == 'Y'||choice == 'y')
        IEEE754::HexiInitial(BinUsed);
        
};
