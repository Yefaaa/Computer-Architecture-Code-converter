//
//  FloatToBinary.hpp
//  Fun
//
//  Created by Yefa Mai on 10/17/16.
//  Copyright © 2016 yefa mai. All rights reserved.
//

#ifndef FloatToBinary_hpp
#define FloatToBinary_hpp

#include <stdio.h>
#include <iostream>
#include <bitset>
#include <string>
#include <sstream>
#include <string.h>
#include "IEEE754.hpp"

using namespace std;


class FloatToBinary :public IEEE754{
private:
    float _number;
    FloatToBinary(){};
public:
    FloatToBinary(int);
    ~FloatToBinary(){};
    void getvalue(float number){_number=number;};
    void intial();
    void excute();
    
    
};

#endif /* FloatToBinary_hpp */
