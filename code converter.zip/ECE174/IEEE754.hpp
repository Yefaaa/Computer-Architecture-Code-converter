//
//  IEEE754.hpp
//  Exercise
//
//  Created by Yefa Mai on 10/15/16.
//  Copyright © 2016 yefa mai. All rights reserved.
//

#ifndef IEEE754_hpp
#define IEEE754_hpp

#include <stdio.h>
#include <math.h>
#include <iostream>
#include <iostream>

using namespace std;

class IEEE754{
private:
    char _number[32];
    IEEE754(){};
    friend class Hexi;
    friend class FloatToBinary;
public:
    ~IEEE754(){};
    IEEE754(int);
    void getvalue(char number[32]);
    void initial();
    void HexiInitial(string);
    
    string sign();
    int expon();
    double decimal();
    
    
    
};




#endif /* IEEE754_hpp */
