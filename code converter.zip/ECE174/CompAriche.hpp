//
//  CompAriche.hpp
//  Exercise
//
//  Created by Yefa Mai on 10/15/16.
//  Copyright © 2016 yefa mai. All rights reserved.
//

#ifndef CompAriche_hpp
#define CompAriche_hpp

#include <stdio.h>

#include <iostream>
#include <cstring>
#include <stdlib.h>
#include "InstruAssembly.hpp"
#include "HexiConvBinary.hpp"
#include "IEEE754.hpp"
#include "FloatToBinary.hpp"

using namespace std;

#endif /* CompAriche_hpp */
